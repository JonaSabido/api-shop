<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateClientsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('clients', function (Blueprint $table) {
            $table->bigIncrements('id');   
            $table->unsignedBigInteger('id_agent')->nullable();         
            $table->string('name');
            $table->string('postal_code');
            $table->string('locality'); 
            $table->string('street'); 
            $table->string('reference',"400");
            $table->string('phone')->nullable();           
            $table->string('email')->nullable(); 
            $table->double('latitude', 15, 8)->nullable(); 
            $table->double('longitude', 15, 8)->nullable();             
            $table->string('type'); 
            $table->string('status');
            $table->timestamps();
            $table->foreign('id_agent')->references('id')->on('agents');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('customers');
    }
}
