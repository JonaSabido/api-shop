<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreatePaymentsDetailTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('payments_detail', function (Blueprint $table) {
            $table->bigIncrements('id'); 
            $table->unsignedBigInteger('id_payment');
            $table->decimal('amount',10,2); 
            $table->date('date');
            $table->foreign('id_payment')->references('id')->on('payments');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('payments_detail');
    }
}
