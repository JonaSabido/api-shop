<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Validator;
use App\Models\Sale;
class SaleController extends CatalogController
{
    public function clazz() {
        return Sale::class;
    }

    protected function makeRelationship(&$entity) {
        $entity->account;
    }

    protected function validator($input) {
        $validator = Validator::make($input, [
            'id_account' => 'required',
            'total' => 'required',
            'type' => 'required',
        ]);
        return $validator;
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
         //
        $object = Sale::find($id);
        $input = $request->getContent();
        if ($object==null) return $this->sendError('Object not found', ['The id is not found'], 404);
        if ($input == null) {
            return $this->sendError('JSON Invalid', ['Input needed'], 406);
        }

        $input = json_decode($input, true);
        if (json_last_error()!==0)
            return $this->sendError('JSON Invalid', ['Malformed JSON'], 406);
        if(isset($input['id_account'])&&$input['id_account']!=='')
            $object->id_account = $input['id_account'];
        if(isset($input['total'])&&$input['total']!=='')
            $object->total = $input['total'];
        if(isset($input['type'])&&$input['type']!=='')
            $object->type = $input['type'];
        $answer=$object->save();
        if ($answer) {
            return response()->json($object, 200);
        }
        return $this->sendError('Update error', ['The object update is not valid'], 500);
    }

}
