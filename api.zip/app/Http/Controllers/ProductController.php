<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Validator;
use App\Models\Product;
class ProductController extends CatalogController
{
    public function clazz() {
        return Product::class;
    }

    protected function makeRelationship(&$entity) {
    }

    protected function validator($input) {
        $validator = Validator::make($input, [
            'name' => 'required',
            'price' => 'required',
            'code' => 'required',
            'sumary' => 'required',
        ]);

        return $validator;
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
         //
        $object = Product::find($id);
        $input = $request->getContent();
        if ($object==null) return $this->sendError('Object not found', ['The id is not found'], 404);
        if ($input == null) {
            return $this->sendError('JSON Invalid', ['Input needed'], 406);
        }

        $input = json_decode($input, true);
        if (json_last_error()!==0)
            return $this->sendError('JSON Invalid', ['Malformed JSON'], 406);
        if(isset($input['name'])&&$input['name']!=='')
            $object->name = $input['name'];
        if(isset($input['price'])&&$input['price']!=='')
            $object->price = $input['price'];
        if(isset($input['code'])&&$input['code']!=='')
            $object->code = $input['code'];
        if(isset($input['sumary'])&&$input['sumary']!=='')
            $object->sumary = $input['sumary'];
        

        $answer=$object->save();
        if ($answer) {
            return response()->json($object, 200);
        }
        return $this->sendError('Update error', ['The object update is not valid'], 500);
    }

}
