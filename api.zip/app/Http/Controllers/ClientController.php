<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Validator;
use App\Models\Client;


class ClientController extends CatalogController
{
    public function clazz() {
        return Client::class;
    }

    protected function makeRelationship(&$entity) {
        $entity->agent;
    }

    protected function validator($input) {
        $validator = Validator::make($input, [
            'name' => 'required',
            'postal_code' => 'required',
            'locality' => 'required',
            'street' => 'required',
            'reference' => 'required',
            'type' => 'required',
            'status' => 'required',
        ]);

        return $validator;
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
         //
        $object = Client::find($id);
        $input = $request->getContent();
        if ($object==null) return $this->sendError('Object not found', ['The id is not found'], 404);
        if ($input == null) {
            return $this->sendError('JSON Invalid', ['Input needed'], 406);
        }

        $input = json_decode($input, true);
        if (json_last_error()!==0)
            return $this->sendError('JSON Invalid', ['Malformed JSON'], 406);
        if(isset($input['id_agent'])&&$input['id_agent']!=='')
            $object->id_agent = $input['id_agent'];
        if(isset($input['name'])&&$input['name']!=='')
            $object->name = $input['name'];
        if(isset($input['postal_code'])&&$input['postal_code']!=='')
            $object->postal_code = $input['postal_code'];
        if(isset($input['locality'])&&$input['locality']!=='')
            $object->locality = $input['locality'];
        if(isset($input['street'])&&$input['street']!=='')
            $object->street = $input['street'];
        if(isset($input['reference'])&&$input['reference']!=='')
            $object->reference = $input['reference'];
        if(isset($input['phone'])&&$input['phone']!=='')
            $object->phone = $input['phone'];
        if(isset($input['id_agent'])&&$input['id_agent']!=='')
            $object->id_agent = $input['id_agent'];
        if(isset($input['email'])&&$input['email']!=='')
            $object->email = $input['email'];
        if(isset($input['Latitude'])&&$input['Latitude']!=='')
            $object->Latitude = $input['Latitude'];
        if(isset($input['Longitude'])&&$input['Longitude']!=='')
            $object->Longitude = $input['Longitude'];
        if(isset($input['type'])&&$input['type']!=='')
            $object->type = $input['type'];
        if(isset($input['status'])&&$input['status']!=='')
            $object->status = $input['status'];

        $answer=$object->save();
        if ($answer) {
            return response()->json($object, 200);
        }
        return $this->sendError('Update error', ['The object update is not valid'], 500);
    }


}
