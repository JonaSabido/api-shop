<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

use Validator;
use App\Models\User;



class UserController extends CatalogController
{
    public function clazz() {
        return User::class;
    }

    protected function makeRelationship(&$entity) {

        $entity->oProfile;

    }

    protected function validator($input) {
        $validator = Validator::make($input, [
            'name' => 'required',
            'email'=> 'required',
            'password' => 'required'
        ]);

        return $validator;
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
        // $input = $request->all();
        $input = $request->getContent();
        $input = json_decode($input);
        $validator = $this->validator($input);

        if ($validator->fails()) {
            return $this->sendError('Validation Error.', $validator->errors());
        } else {
            $input['password'] = bcrypt($input['password']);
            $obj = $this->clazz()::create($input);
            return $this->sendResponse([$obj], 'success');
        }
    }
    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
        $user = User::find($id);
        // Esto hay que implementarlo
        // $input = $request->getContent();
        // $input = json_decode($input);
        $input = $request->all();
        if (isset($input['password'])) {
            $tmp_pass = bcrypt($input['password']);
            if(strcmp($user->password, $tmp_pass)!==0) {
                $user->password = $tmp_pass;
            }
        }
        if(isset($input['name'])) {
            $user->name = $input['name'];
        }
        $user->save();
        return response()->json($user, 200);
    }
}
