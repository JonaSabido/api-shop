<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Validator;
use App\Models\Stock;
class StockController extends CatalogController
{
    public function clazz() {
        return Stock::class;
    }

    protected function makeRelationship(&$entity) {
        $entity->product;
    }

    protected function validator($input) {
        $validator = Validator::make($input, [
            'id_product' => 'required',
            'cost' => 'required',
            'amount' => 'required',
        ]);
        return $validator;
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
         //
        $object = Stock::find($id);
        $input = $request->getContent();
        if ($object==null) return $this->sendError('Object not found', ['The id is not found'], 404);
        if ($input == null) {
            return $this->sendError('JSON Invalid', ['Input needed'], 406);
        }

        $input = json_decode($input, true);
        if (json_last_error()!==0)
            return $this->sendError('JSON Invalid', ['Malformed JSON'], 406);
        if(isset($input['id_product'])&&$input['id_product']!=='')
            $object->id_product = $input['id_product'];
        if(isset($input['cost'])&&$input['cost']!=='')
            $object->cost = $input['cost'];
        if(isset($input['amount'])&&$input['amount']!=='')
            $object->amount = $input['amount'];
        if(isset($input['colour'])&&$input['colour']!=='')
            $object->colour = $input['colour'];
        if(isset($input['deposit'])&&$input['deposit']!=='')
            $object->deposit = $input['deposit'];
        $answer=$object->save();
        if ($answer) {
            return response()->json($object, 200);
        }
        return $this->sendError('Update error', ['The object update is not valid'], 500);
    }

}
