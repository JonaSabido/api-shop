<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Sale extends Model
{
    use HasFactory;
    protected $fillable = [
        'id_account',
        'total',
        'type',
        'acount'
    ];
    public function acount()
    {
        return $this->hasOne(Acount::class, 'id', 'id_account');
    }
}
