<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Account extends Model
{
    use HasFactory;
    protected $fillable = [
        'id_client',
        'ammount',
        'type',
        'status',
        'client'
    ];
    public function client()
    {
        return $this->hasOne(Client::class, 'id', 'id_client');
    }
}
