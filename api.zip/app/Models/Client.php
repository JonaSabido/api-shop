<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Client extends Model
{
    use HasFactory;
    protected $fillable = [
        'id_agent',
        'name',
        'postal_code',
        'locality',
        'street',
        'reference',
        'phone',
        'email',
        'latitude',
        'longitude',
        'type',
        'status'
    ];
    public function agent()
    {
        return $this->hasOne(Agent::class, 'id', 'id_agent');
    }
}
